let async = require('async');
let aws = require('./aws');
let moment = require('moment');
var AWS = aws.aws;
var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var emailUtil = require('./emailutil');

function sendReminder(ReminderItem, cb){
    let userId = ReminderItem.UserId.S;
    let reminderId = ReminderItem.ReminderId.S;
    let reminder_count = parseInt(ReminderItem.reminder_count.N);
    if(ReminderItem.is_active.BOOL == 'false'){
        return cb();
    }
    async.auto({
        accountStatus: (cb) => {
            
            var params = {
                TableName: 'userPlanDetails',
                Key: {
                    'username': {
                        S: userId
                    }
                }
            }
            dynamodb.getItem(params,(err,data) => {
                if(err || !data){
                    cb(err || 'no_data')
                } else {
                    let item = data.Item;
                    let expiryDate = data.Item.plan_expiry_date.N;
                    if(expiryDate == reminderId){
                        cb(null, { status: 'no_change', account: data.Item });
                    } else {
                        cb(null, {status: 'updated', account: data.Item})
                    }
                }
            });
            
        },
        sendEmail: ['accountStatus', ({ accountStatus }, cb) => {
            if(accountStatus.status == 'no_change'){
                reminder_count += 1;
                let fromNow = moment(parseInt(reminderId) * 1000).fromNow(true);
                emailUtil(userId,'purchase-plan-expiry.html','Plan renewal notification', { name: userId, remDays: fromNow }, cb);
            } else {
                cb();
            }
        }],
        updateReminder: ['accountStatus','sendEmail', ({accountStatus, sendEmail}, cb) => {
            let params = {
                TableName: 'PlanRenewReminder',
                Key: {
                    ReminderId: {
                        S: reminderId
                    },
                    UserId: {
                        S: userId
                    }
                }
            }
            if(accountStatus == 'updated'){
                Object.assign(params, {
                    ExpressionAttributeNames: {
                        "#S": "is_active"
                    },
                    ExpressionAttributeValues:{
                        ":s" :{
                            BOOL: false
                        }
                    },
                    UpdateExpression: "Set #S=:s"
                })
            } else {
                // Here update count and next_time
                
                if(reminder_count == 3){
                    Object.assign(params, {
                        ExpressionAttributeNames: {
                            "#S": "is_active",
                            "#R": "reminder_count",
                            "#ST": "status"
                        },
                        ExpressionAttributeValues:{
                            ":s" :{
                                BOOL: false
                            },
                            ":r": {
                                N: reminder_count.toString()
                            },
                            ":st": {
                                S: `Reminder ${reminder_count} Sent`
                            }
                        },
                        UpdateExpression: "Set #S=:s, #R=:r, #ST=:st"
                    })

                } else {
                    let m = moment().add('2', 'days').unix();

                    Object.assign(params, {
                        ExpressionAttributeNames: {
                            "#R": "reminder_count",
                            "#NI": "next_in",
                            "#ST": "status"
                        },
                        ExpressionAttributeValues:{
                            
                            ":r": {
                                N: reminder_count.toString()
                            },
                            ":ni":{
                                N: m.toString()
                            },
                            ":st": {
                                S: `Reminder ${reminder_count} Sent`
                            }
                        },
                        UpdateExpression: "Set #R=:r,#NI=:ni, #ST=:st"
                    })

                }
                
                
            }
            dynamodb.updateItem(params, cb);
        }]
    }, cb);
}

module.exports = (cb) => {
    async.auto({
        toProcessReminder: (cb) => {
            let today = moment().unix();
            var params = {
                TableName: 'PlanRenewReminder',
                FilterExpression: "#pe < :ed",
                ExpressionAttributeNames:{
                    "#pe": "next_in"
                },
                ExpressionAttributeValues: {
                    ":ed": {
                        N: today.toString()
                    }
                }
            }
            dynamodb.scan(params,cb);
    
        },
        expiringAccounts: (cb) => {
            // expiring in 7 days
            let afterSevenDays = moment().add(7,'days').unix();
            var params = {
                TableName: 'userPlanDetails',
                FilterExpression: "#pe < :ed",
                ExpressionAttributeNames:{
                    "#pe": "plan_expiry_date"
                },
                ExpressionAttributeValues: {
                    ":ed": {
                        N: afterSevenDays.toString()
                    }
                }
            }
    
            dynamodb.scan(params,(err, data) => {
                if(err) cb(err)
                else {
                    let formatted = [];
                    let userIds = [];
                    data.Items.forEach((v) => {
                        let obj = {
                            expiryDate: parseInt(v.plan_expiry_date.N),
                            username: v.username.S,
                            plan_type: v.plan_type.S,
                            plan_purchase_date: parseInt(v.plan_purchase_date.N),
                            allocate_file_size: v.allocate_file_size.S,
                            billing_type: v.billing_type.S
                        }
                        let curDate = moment().unix();
                        let diff = obj.expiryDate - curDate;
    
                        let day = 60*60*24;
    
                        let remDays = Math.round(diff / day);
                        obj.remDays = remDays;
                        let fromNow = moment(obj.expiryDate * 1000).fromNow(true);
                        obj.fromNow = fromNow;
                        if(userIds.indexOf(obj.username) == -1){
                            userIds.push(obj.username);
                        }
                        formatted.push(obj);
                    })
    
                    cb(null, {accounts: formatted, userIds });
                }
            });
    
        },
        planRenewReminderSent: ['expiringAccounts', ({expiringAccounts}, cb) => {
            let userIds = expiringAccounts.userIds;
            let uiv = [];
            userIds.forEach((v) => {
                uiv.push({ S: v })
            })
            dynamodb.scan({
                TableName: 'PlanRenewReminder',
                ScanFilter: {
                    UserId: {
                        ComparisonOperator: 'IN',
                        AttributeValueList: uiv
                    }
                }
            }, (err, data) => {
                if(err){
                    cb(err)
                } else {
                    let toR = [];
                    data.Items.forEach((v) => {
                        if(v.is_active){
                            toR.push({
                                UserId: v.UserId.S,
                                ReminderId: v.ReminderId.S,
                                next_in: v.next_in.N
                            })
                        }
                    });
                    
    
                    cb(null, toR)
                }
            });
    
        }],
        
        createPlanRenew: ['expiringAccounts', 'planRenewReminderSent', ({ expiringAccounts: { accounts }, planRenewReminderSent }, cb) => {
            async.each(accounts, (v, cb) => {
                let m = moment().add('10', 'minutes').unix();
                let found = false;
    
                planRenewReminderSent.forEach((v1) => {
                    if(v1.ReminderId == v.expiryDate.toString() && v1.UserId == v.username){
                        found = true;
                    }
                })
                if(!found){
                    dynamodb.putItem({
                        TableName: 'PlanRenewReminder',
                        Item: {
                            UserId: {
                                S: v.username
                            },
                            ReminderId: {
                                S: `${v.expiryDate}`
                            },
                            created_at: {
                                N: moment().unix().toString()
                            },
                            status: {
                                S: 'added'
                            },
                            next_in: {
                                N: m.toString()
                            },
                            reminder_count: {
                                N: '0'
                            },
                            is_active: {
                                BOOL: true
                            }
                        },
        
                    }, cb)
    
                } else {
                    cb();
                }
    
    
            }, cb)
    
        }],
        processReminder: ['toProcessReminder', ({toProcessReminder},cb) => {
            async.each(toProcessReminder.Items, (d, cb) => {
                sendReminder(d, cb);
            }, cb);
    
        }]
    
    },cb);

}


