var aws = require("./aws");
var asyncjs = require('async');
var _ = require('lodash');

var ses = aws.SES;
var s3 = aws.S3;

var templateBucket = process.env.TEMPLATE_BUCKET || "email-templates-13321";
let CognitoIdentityServiceProvider = aws.CognitoIdentityServiceProvider;
let sourceEmail = process.env.SENDER_EMAIL_BILLING ||'info@somcloud.net' 


function sendEmail(username,templatePath, subject, varOptions, cb){

        
    
        asyncjs.auto({
            userEmail: (cb)=> {
                CognitoIdentityServiceProvider.adminGetUser({
                    UserPoolId: 'eu-west-1_WIMnuCJbx',
                    Username: username
                }, function(err, data){
                    if(err){
                        return cb(null,'error_cognito');
                    }
                    let ua = data.UserAttributes;
                    let userEmail = null;
            
                    ua.forEach((v) => {
                        if(v.Name == 'email'){
                            userEmail = v.Value;
                        }
                    })
                    cb(null, userEmail);
                });
    
            },
    
            emailTemplate: (cb) => {
                s3.getObject({
                    Bucket: templateBucket,
                    Key: templatePath
    
                }, function(err, data){
                    if(err){
                        return cb(err)
                    }
                    let d = data.Body.toString();
                    cb(err, d);
                })
            },
            emailSender: ['userEmail', 'emailTemplate', ({userEmail, emailTemplate}, cb) => {
                let vo = _.assign({ email: userEmail },varOptions);
                
                let t = _.template(emailTemplate)(vo);
                if(userEmail === 'error_cognito'){
                    return cb(null, 'error_cognito');
                }
                
                ses.sendEmail({
                    Destination: {
                        ToAddresses: [userEmail]
                    },
                    Message: {
                        Body: {
                            Html: {
                                Data: t
                            }
                        },
                        Subject: {
                            Data: subject
                        }
                    },
                    Source: sourceEmail
                }, (err,data) => {
                    console.log('Got errror', err)
                    
                    cb(null, err ? 'errored': 'processed');
                })
            }],
        }, (err, data) => {
            if(err){
                console.log('Got error',err)
                cb(err);
            } else {
                console.log('Got data', data)
                cb(null, data);
            }
        });
    // })    
}
module.exports = sendEmail;