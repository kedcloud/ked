AWS = require("aws-sdk");
let awsConfig = {
  "region": "eu-west-1",
//   "endpoint": "cognito-idp.eu-west-1.amazonaws.com",
  // "accessKeyId": "AKIAYMD53H7WFIIESXQ5",
  // "secretAccessKey": "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"
}
AWS.config.update(awsConfig);
var sqs = new AWS.SQS({ apiVersion: '2012-11-05' });
var s3 = new AWS.S3({
  // "accessKeyId": "AKIAYMD53H7WFIIESXQ5",
  // "secretAccessKey": "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",
  "region": "eu-west-1"
});
var ses = new AWS.SES();
let CognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider({
    "region": "eu-west-1",
    "endpoint": "cognito-idp.eu-west-1.amazonaws.com",
    // "accessKeyId": "AKIAYMD53H7WFIIESXQ5",
    // "secretAccessKey": "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"
  });


module.exports = {
  "aws": AWS,
  "S3": s3,
  "sqs": sqs,
  "SES": ses,
  'CognitoIdentityServiceProvider': CognitoIdentityServiceProvider
}