var AWS = require('aws-sdk');
// var dynamodb = new AWS.DynamoDB();
var async = require('async');
var s3 = new AWS.S3();

function getWithoutError(img, key){
    try{
        return img['file']['M'][key]['S'];
    } catch(e){
        return null;
    }
}


exports.handler =  (event, context, callback) => {
    // TODO implement
    let records = event.Records;
    let status = [];
    async.each(records, (r, cb) => {
        // console.log(r);
        if(r.eventSource == 'aws:dynamodb'){
            if(r.eventName == 'REMOVE' && r.dynamodb.OldImage){
                let bucketName = getWithoutError(r.dynamodb.OldImage,'bucket');
                let key = getWithoutError(r.dynamodb.OldImage,'key');
                console.log(bucketName, key);
                // Remove from s3
                if(!bucketName || !key){
                    cb();
                } else {
                    var params = {  Bucket: bucketName, Key: key };
                    s3.deleteObject(params, (err, data) => {
                        console.log(err,data);
                        if(err){
                            status.push({
                                id: r.dynamodb.Keys.id.S,
                                err: err
                            })
                            console.log('Got error', err);
                        } else {
                            status.push({
                                id: r.dynamodb.Keys.id.S,
                                message: 'DELETED'
                            })

                        }
                        cb();
                    })
                }
            } else {
                console.log('not handling',r);
                cb();
            }
        } else {
            cb();
        }
        
    }, (err) => {
        callback(null, { status: status })
    })
    // const response = {
    //     statusCode: 200,
    //     body: JSON.stringify(event),
    // };
    // return response;
};
