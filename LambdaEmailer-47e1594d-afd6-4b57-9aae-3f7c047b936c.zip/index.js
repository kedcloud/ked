var aws = require("./libs/aws");
var asyncjs = require('async');
var _ = require('lodash');

var AWS = aws.aws;
var ses = aws.SES;
var s3 = aws.S3;

var templateBucket = process.env.TEMPLATE_BUCKET || "email-templates-13321";
let CognitoIdentityServiceProvider = aws.CognitoIdentityServiceProvider;
var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});


function sendEmail(username, emailType,  emailId, templatePath, subject, varOptions, cb){

    // return new Promise((resolve, reject) => {
        
    
        asyncjs.auto({
            userEmail: (cb)=> {
                CognitoIdentityServiceProvider.adminGetUser({
                    UserPoolId: 'eu-west-1_WIMnuCJbx',
                    Username: username
                }, function(err, data){
                    if(err){
                        return cb(null,'error_cognito');
                    }
                    let ua = data.UserAttributes;
                    let userEmail = null;
            
                    ua.forEach((v) => {
                        if(v.Name == 'email'){
                            userEmail = v.Value;
                        }
                    })
                    cb(null, userEmail);
                });
    
            },
    
            emailTemplate: (cb) => {
                s3.getObject({
                    Bucket: templateBucket,
                    Key: templatePath
    
                }, function(err, data){
                    if(err){
                        return cb(err)
                    }
                    let d = data.Body.toString();
                    cb(err, d);
                })
            },
            emailSender: ['userEmail', 'emailTemplate', ({userEmail, emailTemplate}, cb) => {
                let vo = _.assign({ email: userEmail },varOptions);
                
                let t = _.template(emailTemplate)(vo);
                if(userEmail === 'error_cognito'){
                    return cb(null, 'error_cognito');
                }
                
                ses.sendEmail({
                    Destination: {
                        ToAddresses: [userEmail]
                    },
                    Message: {
                        Body: {
                            Html: {
                                Data: t
                            }
                        },
                        Subject: {
                            Data: subject
                        }
                    },
                    Source: process.env.SENDER_EMAIL_BILLING
                }, (err,data) => {
                    console.log('Got errror', err)
                    
                    cb(null, err ? 'errored': 'processed');
                })
            }],
            emailSentUpdate: ['emailSender', ({emailSender}, cb) => {
                dynamodb.updateItem({
                    TableName: 'UserEmailQueue',
                    Key: {
                        user_id: {
                            S: username
                        },
                        email_id: {
                            S: emailId
                        }
                    },
                    ExpressionAttributeNames: {
                        "#S": "status"
                    },
                    ExpressionAttributeValues:{
                        ":s" :{
                            S: emailSender
                        }
                    },
                    UpdateExpression: "Set #S=:s"
                }, cb);
    
            }]
        }, (err, data) => {
            if(err){
                console.log('Got error',err)
                cb(err);
            } else {
                console.log('Got data', data)
                cb(null, data);
            }
        });
    // })    
}
function getValueOf(item, location){
    try{
        return item[location]
        
    }catch(e){
        return null
    }
}


exports.handler = (event, context, callback) => {
    // TODO implement
    let records = event.Records;
    let r = [];
    
    asyncjs.each(records, (item, cb) => {
        if(item.eventSource ==  'aws:dynamodb' && item.eventName === 'INSERT'){
            let status = getValueOf(item,'dynamodb.NewImage.status.S');
            if(status != 'added'){
                return cb();
            }
            
            let user_id = item.dynamodb.Keys.user_id.S;
            let email_id = item.dynamodb.Keys.email_id.S;
            let emailType = getValueOf(item,'dynamodb.NewImage.email_type.S');
            let templatePath = item.dynamodb.NewImage.template_path.S;
            let varOptions = JSON.parse(item.dynamodb.NewImage.var_options.S);
            let subject = item.dynamodb.NewImage.subject.S;
            
            
            
            console.log('Processing item', email_id);

            

            sendEmail(user_id,emailType,email_id,templatePath,subject,varOptions, (err, data) => {
                if(err){
                    cb(err)
                } else {
                    r.push(data)
                    cb();
                }
            });
        } else {
            cb();
        }
        
    }, (err) => {
        console.log('Got error', err);
        callback(err, r);
        
    })

    // records.forEach(async (item) => {
    //     // console.log('Got item', item);
    //     if(item.eventSource ==  'aws:dynamodb' && item.eventName === 'INSERT'){
            
    //         let user_id = item.dynamodb.Keys.user_id.S;
    //         let email_id = item.dynamodb.Keys.email_id.S;
    //         let emailType = item.dynamodb.NewImage.email_type.S;
    //         let templatePath = item.dynamodb.NewImage.template_path.S;
    //         let varOptions = JSON.parse(item.dynamodb.NewImage.var_options.S);
    //         let subject = item.dynamodb.NewImage.subject.S;
    //         console.log('Processing item', email_id);

            

    //         let es = await sendEmail(user_id,emailType,email_id,templatePath,subject,varOptions);
    //         console.log('Processing completed');
    //         r.push(es);
    //     }
    // })

    // return r;
};
