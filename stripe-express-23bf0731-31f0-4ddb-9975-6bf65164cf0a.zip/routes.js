const AuthController = require('./controllers/AuthController');
const express = require('express');
const router = express.Router();
const store = require('./libs/store');
const stripe = require("stripe")("sk_live_mhqr1n8iqJgn84WNwNFHjFht00D1SAIs9T");
const moment = require('moment');


router.get('/confirmSignup', AuthController.confirmSignup);
router.get('/health' , (req, res, next) => {  res.send('ok')})
function setUserDetails(event){
  return new Promise((resolve,reject) => {
        console.log('setUserDetails', event);
        var currentTime = moment(new Date());
        let allocate_file_size,expiry_date;
        if (event.plan_type == "standard") {
          allocate_file_size = "2000GB";
        }
        else {
          allocate_file_size = "5000GB";
        }
        if (event.billing_type == "montly") {
          expiry_date = currentTime.add(1, 'M').unix().toString();
        }
        else {
          expiry_date = currentTime.add(1, 'Y').unix().toString();
        }
        var planPurchaseDate = moment(new Date()).unix().toString();

        store.addUserPlan(event.username, event.plan_type, allocate_file_size, event.billing_type, expiry_date, planPurchaseDate, function(err,data){
          if(err){
            reject(err)
          } else{
            resolve(data);
          }
        })
  })
        
       
}
function addToEmailQueue(username, emailType, emailId, templatePath, subject, varOptions){
  return new Promise((resolve, reject) => {
    console.log('addToEmailQueue', username, templatePath);
    store.addToEmailQueue(username, emailType, emailId, templatePath, subject, JSON.stringify(varOptions), (err, data) => {
      if(err){
        reject(err)
      } else {
        resolve(data);
      }
    })
  })
}
function getUserDetails(username){
  return new Promise((resolve, reject) => {
    store.getUserDetails(username, (err, data) => {
      if(err){
        reject(err)
      } else {
        resolve(data);
      }
    })
  })
}
router.post('/api/donate', async(req,res,next)=>{
    const token = req.body.payload.token.id; // Using Express
    const total = req.body.total;
    //user info to be stored 
    const user = req.body.info;
    
    let plan = user.plan_name || 'standard';
    let billingType = user.billing_type || 'monthly';
    // let billingType = active === 'first' ? 'monthly' : 'yearly' 


    try{
        let username = user.firstname;
        let skip = username === process.env.SKIP_FIRSTNAME;
        let charge;

        if(!skip){
          charge = await stripe.charges.create({
            amount:Number(total)*100,
            currency: 'usd',
            description: `Purchased ${plan} - ${billingType} in kedcloud.com`,
            source: token,
            });
        }
        
        if(charge || skip){

            let userDetails = await getUserDetails(username)
            
            var timeNow = Date.now()
            let pms = {
              name: username,
              price: `$${Number(total)}`,
              plan_name: plan,
              email: userDetails.email

            }
            await addToEmailQueue(username, 'plan_purchased_success', `${username}-${plan}-${billingType}-${timeNow}`,  'thankyou-paid.html','Thank you for the purchase', pms)
            await setUserDetails({ username: username, plan_type: plan, billing_type: billingType  })
            res.status(200).send("success");
        }
            
    }catch(e){
        console.log(e);
        res.status(400).send(e);
    }

 
});
module.exports = router;