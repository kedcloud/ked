const AWS = require('aws-sdk');

const s3 = new AWS.S3();
var params = {
    Bucket: 'aws-amplify-graphql-amgraphenv'    
};

exports.handler = async (event, context) => {
    // TODO implement
    var Totsize = [];
    
    console.log("asdfadsfads", event)
    
    const key = event['identityId'];
    
    await getSize(params, Totsize, key);
    
    const response = {
        statusCode: 200,
        body: Totsize[0]
    };
    return response;
};


async function getSize(params, sizes, key){
    var tsize = 0;
    const response = await s3.listObjectsV2(params).promise();
    response.Contents.forEach(obj => {
        if (obj.Key.includes(key)){
            tsize = tsize + parseInt(obj.Size);    
        } 
    });
    sizes.push(tsize);
}