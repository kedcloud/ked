let AWS = require("aws-sdk");
var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

function  addUserPlan(username, planType, fileSize, billingType, planExpiry, planPurchase, cb){
    var params = {        
        Item: {
            username: {
                S: username
            },
            'plan_type':{
                S: planType
            },
            'allocate_file_size': {
                S: fileSize
            },
            'billing_type': {
                S: billingType
            },
            'plan_expiry_date': {
                N: planExpiry
            },
            'plan_purchase_date': {
                N: planPurchase
            }
        },
        ReturnConsumedCapacity: 'TOTAL',
        TableName: 'userPlanDetails'
      }

     dynamodb.putItem(params, cb);
}

function setUserDetails(event){
    return new Promise((resolve,reject) => {
          console.log('setUserDetails', event);
          var currentTime = new Date();
          let allocate_file_size = "5GB";
          let billingType = "monthly";
          let expiry_date = Math.trunc(currentTime.setMonth(currentTime.getMonth() + 1)/1000).toString()
          var planPurchaseDate = Math.trunc(Date.now()/1000).toString();
          var planType = "trial";
  
          addUserPlan(event.userName, planType, allocate_file_size, billingType, expiry_date, planPurchaseDate, function(err,data){
            if(err){
              reject(err)
            } else{
              resolve(data);
            }
          })
    })
          
         
  }

exports.handler = async (event) => {
    // TODO implement
    
    await setUserDetails(event);
   
    return event;
};
