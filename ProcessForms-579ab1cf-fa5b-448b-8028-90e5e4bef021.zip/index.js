let AWS = require("aws-sdk");
var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ses = new AWS.SES();

function sendEmail(email, source, callback) {
    ses.sendTemplatedEmail({
        Destination: {
            ToAddresses: [email]
        },
        TemplateData: JSON.stringify({}),
        Source: source,
        Template: "ContactThankYou"
    }, callback)
    
    // body...
}

function sendContacted(input, toAdd, template, callback) {
    ses.sendTemplatedEmail({
        Destination: {
            ToAddresses: [toAdd]
        },
        TemplateData: JSON.stringify(input),
        Source: "info@kedcloud.com",
        Template: template
    }, callback)
    
    // body...
}
exports.handler =  (event, context, callback) => {
    // TODO implement
    let input = event.arguments.input;
    let field = event.field;
    
    if(field == 'ContactUs'){
        var params = {        
            Item: {
                email: {
                    S: input.email
                },
                'comment_id':{
                    S: input.comment_id
                },
                'comment': {
                    S: input.comment
                },
                'phone_number': {
                    S: input.phone_number
                },
                'topic': {
                    S: input.topic
                }
            },
            TableName: 'contact_us'
          }
        
        dynamodb.putItem(params,(err,data) => {
            if(err){
                console.log(err)
                callback(null, { error: 'Error writing' })
            } else {
                sendEmail(input.email, "info@kedcloud.com", (err, data) => {
                    console.log('se', err,data)
                    sendContacted(input,"info@kedcloud.com", "UserContacting", (err,data) => {
                        console.log('contacted', err,data)
                        callback(null, input);
                    })
                    
                })
                
            }
        })
        
    } else {
        var params = {        
        Item: {
            email: {
                S: input.email
            },
            'timestamp':{
                S: input.timestamp
            },
            'name': {
                S: input.name
            },
            'account_number': {
                S: input.account_number
            },
            'mobile': {
                S: input.mobile
            },'plan': {
                S: input.plan
            }
        },
        TableName: 'payment_form'
      }
    
    dynamodb.putItem(params,(err,data) => {
        if(err){
            console.log(err)
            callback(null, { error: 'Error writing' })
        } else {
            sendEmail(input.email, "billing@kedcloud.com", (err, data) => {
                console.log('se', err,data)
                sendContacted(input, "billing@kedcloud.com","UserContactingBilling",  (err,data) => {
                    console.log('contacted', err,data)
                    callback(null, input);
                })
                
            })
            
        }
    })
        
    }
    
};
