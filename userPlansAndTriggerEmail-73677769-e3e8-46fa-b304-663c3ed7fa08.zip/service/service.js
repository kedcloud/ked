exports.getUsersFromCognito = (CognitoIdentityServiceProvider) => {
    return new Promise(function (resolve, reject) {
        var params = {
            UserPoolId: "eu-west-1_WIMnuCJbx"
        }
        CognitoIdentityServiceProvider.listUsers(params, function (error, data) {
            if (error) {
                reject(error);
            }
            else {
                resolve(data);
            }
        })
    })
}

exports.getUserFromCognito = (CognitoIdentityServiceProvider, email) => {
    return new Promise(function (resolve, reject) {
        var params = {
            UserPoolId: "eu-west-1_WIMnuCJbx",
            Username: email,
        }
        CognitoIdentityServiceProvider.adminGetUser(params, function (error, data) {
            if (error) {
                reject(error)
            }
            else {
                resolve(data)
            }
        })
    })
}