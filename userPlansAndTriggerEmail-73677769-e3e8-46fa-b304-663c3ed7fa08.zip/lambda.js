AWS = require('./libs/aws.js'),
  aws = AWS.aws,
  service = require('./service/service.js'),
  moment = require('moment'),
  _=require('underscore'),
  CognitoIdentityServiceProvider = new aws.CognitoIdentityServiceProvider(),
  s3 = AWS.s3;

exports.handler = function (event, context, callback) {
  //console.log("ee", event);
  var expiry_date, allocate_file_size, CognitoIdentityServiceProvider = new aws.CognitoIdentityServiceProvider();
  if (event.username) {
    service.getUserFromCognito(CognitoIdentityServiceProvider, event.username).then(async (user, err) => {
      if (err) callback(err, user);
      var currentTime = moment(new Date());
      if (event.plan_type == "standard") {
        allocate_file_size = "2000GB";
      }
      else {
        allocate_file_size = "5000GB";
      }
      if (event.billing_type == "montly") {
        expiry_date = currentTime.add(1, 'M').unix().toString();
      }
      else {
        expiry_date = currentTime.add(1, 'Y').unix().toString();
      }
      var planPurchaseDate = moment(new Date()).unix().toString();
      // console.log("EE", expiry_date);
      var params = {
        UserPoolId: "eu-west-1_WIMnuCJbx",
        Username: event.username,
        UserAttributes: [
          { Name: "custom:plan_type", Value: event.plan_type },
          { Name: "custom:billing_type", Value: event.billing_type },
          { Name: "custom:allocate_file_size", Value: allocate_file_size },
          { Name: "custom:plan_expire_date", Value: expiry_date },
          { Name: "custom:data_upload_size", Value: "0 Bytes" },
          { Name: "custom:plan_purchased_date", Value: planPurchaseDate },
        ]
      }
      await CognitoIdentityServiceProvider.adminUpdateUserAttributes(params, function (error, data) {
        if (error) callback(error, data);
        callback(null, { "Status": 200, "Message": "User Plan is saved" });
      })
    })
  }
  else {
    service.getUsersFromCognito(CognitoIdentityServiceProvider).then((users, err) => {
      if (err) callback(err, users);
      var users = users.Users;
      
      for (i = 0; i < users.length; i++) {
        console.log('UU', users[i]);
        var plan_type = _.findWhere(users[i].Attributes, { "Name": "custom:plan_type" }),expiry_date,
        currentDate=moment(new Date()).unix();
        if (plan_type == undefined) {
          var userCreatedDate = users[i].UserCreateDate,
            userCreatedTimestamp = moment(new Date(userCreatedDate)).unix();
          console.log("TIme", userCreatedTimestamp);
          expiry_date = moment(new Date(userCreatedDate)).add(1, 'M').unix();
          console.log("Trail", expiry_date);
        }
        else {
          expiry_date = _.findWhere(users[i].Attributes, { "Name": "custom:plan_expiry_date" });
          
          
          //  var plan_expiry_date=
          // service.sendMail().then((sucess, err) => {

          // })
        }


        //if()
      }
      users.Users.forEach((user) => {
        console.log("Users", user.Attributes);
      })
      //  console.log("Users", users.Users[0].Attributes);

    })
  }
}