const AWS = require('aws-sdk');

const s3 = new AWS.S3();
var params = {
    Bucket: 'eurosombucket-eurosoms'    
};

exports.handler = async function(event, context, callback) {
   
    console.log("event", event)
    var allKeys = [];
    var Totsize = [];
    var keyObjects = [];
    console.log("context", context);
    console.log(event.Records[0].s3)
    const key = event.Records[0].s3.object.key
    const id = key.split('/')[1]
    await getSize(params, Totsize, id.replace('%3A', ':'));
    console.log("fsize", Totsize);
    if(Totsize[0] > 1048576) {
        console.log('called')
        var nparams = {
            Bucket: "eurosombucket-eurosoms", 
            Key: key
        };
        console.log("nparams", nparams);
        s3.deleteObject(nparams, function(err, data) {  
            console.log(data); 
            if (err) 
                console.log(err, err.stack); // an error occurred
            else     
                console.log("successfully", data);           // successful response
        });
    }
    // if(Totsize < 1048576) {
        // console.log("file is small than 10 mb")
        // console.log("getKeyfunc");
        // await getKeys(params, allKeys);
        // console.log("allKeys", allKeys);
        // allKeys.forEach(obj => {
        //     var nparams = {
        //         Bucket: "eurosombucket-eurosoms", 
        //         Key: obj.Key
        //     };
        //     console.log("nparams", nparams);
        //     s3.deleteObject(nparams, function(err, data) {  console.log(data); 
        //         if (err) console.log(err, err.stack); // an error occurred
        //         else     console.log(data);           // successful response
        //     });
        // });
        
    // }

    callback(null, 'message')
}


async function getSize(params, keys, id){
    var tsize = 0;
    const response = await s3.listObjectsV2(params).promise();
    response.Contents.forEach(obj => {
        if (obj.Key.includes(id)){
            tsize = tsize + parseInt(obj.Size);    
        } 
    });
    keys.push(tsize);
    
    if (response.IsTruncated) {
        const newParams = Object.assign({}, params);
        newParams.ContinuationToken = response.NextContinuationToken;
        await getKeys(newParams, keys); // RECURSIVE CALL
    }
}


async function getKeys(params, keys){
   
    const response = await s3.listObjectsV2(params).promise();
    response.Contents.forEach(obj => {
     
        var todaydate = new Date();
        var imagedate = new Date(obj.LastModified);
        var timeDiff = Math.abs(todaydate.getTime() - imagedate.getTime());
        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        var filesDeleted=0;
        if(diffDays>=30) {
            keys.push(obj);
        }
    });
    if (response.IsTruncated) {
        const newParams = Object.assign({}, params);
        newParams.ContinuationToken = response.NextContinuationToken;
        await getKeys(newParams, keys); // RECURSIVE CALL
    }
}
