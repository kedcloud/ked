let main = require('./main');
exports.handler =  function(event, context, callback) {
    main(callback)
}
